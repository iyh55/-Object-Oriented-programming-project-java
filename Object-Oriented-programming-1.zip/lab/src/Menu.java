import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;
public class Menu {

    private int choice;
    private String menuBrakfast;
    private String menuDinner;
    private String menuCoffee;
    private String inp="\n";

    public Menu(int choice) {
        choice = choice;
    }

    public Menu() {
        choice=0;
        menuBrakfast="";
        menuDinner="";
        menuCoffee="";
        inp="";
    }

    /**
      This function change the value of choice .
     * @param choice
     */
    public void setChoice(int choice) {
        this.choice = choice;

    }

    /**
      This fuction returns the menu of breakfast
     * @return inp(menuBreakfast)
     * @throws IOException
     */
    public String getmenuBrakfast()throws IOException
    {

        File file=new File("Breakfast.txt");
        Scanner read=new Scanner(file);

        while(read.hasNext())
        {
            menuBrakfast=read.nextLine()+"\n";
            inp+=menuBrakfast;
        }


        read.close();
        return inp;
    }

    /**
     This fuction returns the menu of Dinner
     * @return inp(menuDinner)
     * @throws IOException
     */
    public String getmenuDinner()throws IOException
    {
        File file = new File("Dinner.txt");
        Scanner inputFile = new Scanner(file);
        while (inputFile.hasNext())
        {
            menuDinner =inputFile.nextLine()+"\n";

            inp+=menuDinner;
        }

        inputFile.close();

        return inp;
    }

    /**
     This fuction returns the menu of Coffee
     * @return inp(menuCoffee)
     * @throws IOException
     */

    public String getmenuCoffee() throws IOException {

        File file=new File("Coffee.txt");
        Scanner read=new Scanner(file);

        while(read.hasNext())
        {
            menuCoffee=read.nextLine()+"\n";
            inp+=menuCoffee;
        }
        read.close();

        return inp;
    }

}




