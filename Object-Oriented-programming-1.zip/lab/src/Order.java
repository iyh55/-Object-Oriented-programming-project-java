public class Order {
    private int tableNumber;
    private int yourOrder;
    private int numOfo;
    private double pric;

    private  int[] pricesOfbreakfast={80,30,15,12,10};
    private  int[] pricesOfdinner={95,80,90,90,50};
    private  int[] pricesOfcoffee={22,18,20,12,19,20,9,20};


    public Order() {
        tableNumber=0;
        yourOrder=0;
        numOfo=0;
        pric=0;
    }

    public Order( int yourOrder) {
        this.yourOrder = yourOrder;
    }

    public Order(double pric) {

        this.pric = pric;
    }

    public Order(Order order) {
        this.tableNumber = order.tableNumber;
        this.pric=order.pric;
        this.yourOrder=order.yourOrder;
        this.numOfo=order.numOfo;
    }

    /**
     This function determines the number of orders by the customer
     * @param numOfo
     */
    public void setNumOfo(int numOfo) {

        this.numOfo = numOfo;
    }

    /**
     This function calculates the price for the costmer if he choose the Breakfast menu
     * @param yourOrder
     */
    public void setYourOrderB(int yourOrder) {

        this.yourOrder = yourOrder;

        if (this.yourOrder == 1) {
            pric += pricesOfbreakfast[0];
        }
        if (this.yourOrder == 2) {
            pric += pricesOfbreakfast[1];
        }
        if (this.yourOrder == 3) {
            pric += pricesOfbreakfast[2];
        }
        if (this.yourOrder == 4) {
            pric += pricesOfbreakfast[3];
        }
        if (this.yourOrder == 5) {
            pric += pricesOfbreakfast[4];
        }

    }

    /**
     This function calculates the price for the costmer if he choose the dinner menu
     * @param yourOrder
     */

    public void setYourOrderD(int yourOrder) {

        this.yourOrder = yourOrder;

        if (this.yourOrder == 1) {
            pric += pricesOfdinner[0];
        }
        if (this.yourOrder == 2) {
            pric += pricesOfdinner[1];
        }
        if (this.yourOrder == 3) {
            pric += pricesOfdinner[2];
        }
        if (this.yourOrder == 4) {
            pric += pricesOfdinner[3];
        }
        if (this.yourOrder == 5) {
            pric += pricesOfdinner[4];
        }

    }

    /**
     This function calculates the price for the costmer if he choose the coffee menu
     * @param yourOrder
     */
    public void setYourOrderC(int yourOrder) {

        this.yourOrder = yourOrder;

        if (this.yourOrder == 1) {
            pric += pricesOfcoffee[0];
        }
        if (this.yourOrder == 2) {
            pric += pricesOfcoffee[1];
        }
        if (this.yourOrder == 3) {
            pric += pricesOfcoffee[2];
        }
        if (this.yourOrder == 4) {
            pric += pricesOfcoffee[3];
        }
        if (this.yourOrder == 5) {
            pric += pricesOfcoffee[4];
        }
        if (this.yourOrder == 6) {
            pric += pricesOfcoffee[5];
        }
        if (this.yourOrder == 7) {
            pric += pricesOfcoffee[6];
        }
        if (this.yourOrder == 8) {
            pric += pricesOfcoffee[7];
        }

    }

    /**
     This fuction return the price
     * @return
     */
    public double getPrice()
    {

        return this.pric;
    }

}