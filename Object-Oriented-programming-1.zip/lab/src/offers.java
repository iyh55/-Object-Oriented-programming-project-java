public class offers {

    private Order price;

    public offers (Order p)
    {
        price = p;
    }

    public offers() {
        price=null;

    }


    public offers(offers o) {
        this.price=o.price;
    }

    /**

     * @param price
     */
    public offers(double price) {

        if(price>=200&& price <=399)
        {
            Offers1();
        }
        else if(price>=400&& price <= 599)
        {
            Offers2();
        }
        else if(price>=600)
        {
            Offers3(price);
        }

    }

    /**
     This function if the customer's price is greater than or equal to 200 or less than or equal to 399, the first offer will be executed
     */
    public void Offers1()
    {

        System.out.println("\n you have offers :");
        System.out.println(" Two pieces of cake of your choice" +
                "in addition to American coffee ");
    }

    /**
     This function if the customer's price is greater than or equal to 400 or less than or equal to 599, the second offer will be executed
     */
    public void Offers2()
    {

        System.out.println("\n you have offers :");
        System.out.println("4 pieces of cake of your choice\n" +
                "in addition to two cups of coffee of your choice ");
    }

    /**
     This function, if the customer price exceeds 600, will make a 30% discount for him
     * @param price
     */
    public void Offers3(double price)
    {

        System.out.println("\nYou have Dicount 30%");
        double dicount= (price*0.3);
        double newprice = price - dicount;


        System.out.println("New price = " +newprice);

    }

}