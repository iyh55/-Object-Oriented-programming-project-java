public class Costmer {
    private String CostmerName;
    private int PhoneNumber;
    private Order order;


    public Costmer(String costmerName, int phoneNumber, Order o) {
        CostmerName = costmerName;
        PhoneNumber = phoneNumber;
        order = o;
    }

    /**
     This copy cnstruactor
     * @param o1
     */
    public Costmer(Costmer o1) {
        CostmerName = o1.CostmerName;
        PhoneNumber = o1.PhoneNumber;
        order=o1.order;
    }


    public Costmer() {
        CostmerName="";
        PhoneNumber=0;
        order=null;

    }

    /**
     *
     * @param o
     */
    public void setOrder(Order o) {

        this.order = new Order(o);
    }

    /**
     This fuction set the costmer name
     * @param name
     */
    public void setCostmerName(String name) {

        CostmerName = name;
    }

    /**
     This fuction set the costmer phone number
     * @param phone
     */
    public void setphoneNumber(int phone) {

        PhoneNumber = phone;
    }

    /**
     This fuction returns the costmer name
     * @return CostmerName
     */
    public String getCostmerName() {

        return CostmerName;
    }

    /**
     This fuction returns the costmer phone number
     * @return PhoneNumber
     */
    public int getphoneNumber() {

        return PhoneNumber;
    }

    /**
     *
     * @return str
     */
    @Override
    public String toString() {

        String str ;
        str= "\n"+"Costmer Name =" + CostmerName + "\n" +
                "phoneNumber = " + PhoneNumber + "\n" + "Your Price= " + order.getPrice();

        return str;
    }
}

