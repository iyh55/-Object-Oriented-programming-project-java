import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import  java.util.Random;


public class Main {
    public static void main(String[] args) throws IOException {
        String input;
        int choice;
        int phone;
        int numOforder;
        int yourorder = 0;
        int table;
        int invoice;
        Order o1 = new Order();
        Costmer c1 = new Costmer();

        System.out.println("\n\t\tWELCOM  TO DHYARA LAOUNGE");


        Scanner keyboard = new Scanner(System.in);

        System.out.println(" Please enter your name :");
        input = keyboard.nextLine();
        c1.setCostmerName(input);
        System.out.println("Please enter your phone number to receive any offers :");
        phone = keyboard.nextInt();
        c1.setphoneNumber(phone);

        Random rand = new Random();
        table = rand.nextInt(10) + 1;
        invoice = rand.nextInt(200) + 1;

        System.out.println(" 1- Menu of Brakfast\n 2- Menu of Dinner\n 3- Menu of coffee\n");
        System.out.println(" Choose the menu to display ");

        Menu m1 = new Menu();
        choice = keyboard.nextInt();

        switch (choice) {
            case 1:
                m1.setChoice(choice);
                System.out.println(m1.getmenuBrakfast());
                System.out.println(" \t\tWe have a list of offers");
                System.out.println("The first show :\n" +
                        "If the price is more than 200 riyals \n" +
                        "Two pieces of cake of your choice" +
                        "in addition to American coffee");
                System.out.println("The Secend show :\n" +
                        "If the price is more than 400 riyals\n" +
                        "4 pieces of cake of your choice" +
                        "in addition to two cups of coffee of your choice ");
                System.out.println("The thied show :\n" +
                        "If the price is more than 600 riyals\n" +
                        "You have Dicount 30%");

                System.out.println("\n\nPlease enter the number of meals you want to order:");
                numOforder = keyboard.nextInt();
                o1.setNumOfo(numOforder);

                for (int j = 1; j <= numOforder; j++) {
                    System.out.println("\nPlease choose the order number  " + j + ":");
                    yourorder = keyboard.nextInt();
                    o1.setYourOrderB(yourorder);
                }
                break;
            case 2:
                m1.setChoice(choice);
                System.out.println(m1.getmenuDinner());
                System.out.println(" \t\tWe have a list of offers");
                System.out.println("The first show :\n" +
                        "If the price is more than 200 riyals \n" +
                        "Two pieces of cake of your choice" +
                        "in addition to American coffee");
                System.out.println("The Secend show :\n" +
                        "If the price is more than 400 riyals\n" +
                        "4 pieces of cake of your choice" +
                        "in addition to two cups of coffee of your choice ");
                System.out.println("The thied show :\n" +
                        "If the price is more than 600 riyals\n" +
                        "You have Dicount 30%");

                System.out.println("\n\nPlease enter the number of meals you want to order:");
                numOforder = keyboard.nextInt();
                o1.setNumOfo(numOforder);

                for (int j = 1; j <= numOforder; j++) {
                    System.out.println("\nPlease choose the order number   " + j + ":");
                    yourorder = keyboard.nextInt();
                    o1.setYourOrderD(yourorder);
                }
                break;
            case 3:
                m1.setChoice(choice);
                System.out.println(m1.getmenuCoffee());
                System.out.println(" \t\tWe have a list of offers");
                System.out.println("The first show :\n" +
                        "If the price is more than 200 riyals \n" +
                        "Two pieces of cake of your choice" +
                        "in addition to American coffee");
                System.out.println("The Secend show :\n" +
                        "If the price is more than 400 riyals\n" +
                        "4 pieces of cake of your choice" +
                        "in addition to two cups of coffee of your choice ");
                System.out.println("The thied show :\n" +
                        "If the price is more than 600 riyals\n" +
                        "You have Dicount 30%");

                System.out.println("\n\nPlease enter the number of meals you want to order:");
                numOforder = keyboard.nextInt();
                o1.setNumOfo(numOforder);

                for (int j = 1; j <= numOforder; j++) {
                    System.out.println("\nPlease choose the order number " + j + ":");
                    yourorder = keyboard.nextInt();
                    o1.setYourOrderC(yourorder);
                }
                break;
            default:
                System.out.println("wrong choice");
        }



        FileWriter file_name = new FileWriter("CostmerData.txt");
        PrintWriter wdata = new PrintWriter(file_name);

        wdata.println("\t\tDHYARA LAOUNG");
        wdata.println("\t\tinvoice #" + invoice);
        wdata.printf("\nYour name :" + input);
        wdata.printf("\nYour phone number: " + phone);
        wdata.println("\nYour Table Noumber :" + table);
        wdata.printf("\nYour price =" + o1.getPrice() + "Sr");

        wdata.close();

        c1.setOrder(o1);
        double pr;
        pr=o1.getPrice();

        System.out.println(c1);
        offers ofers = new offers(pr);
    }

}